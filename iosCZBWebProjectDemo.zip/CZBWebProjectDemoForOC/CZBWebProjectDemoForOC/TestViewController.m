//
//  TestViewController.m
//  CZBWebProjectDemoForOC
//
//  Created by 李旭 on 2019/8/13.
//  Copyright © 2019 czb365.com. All rights reserved.
//

#import "TestViewController.h"
#import "WebViewController.h"
@interface TestViewController ()
@property(nonatomic,strong)UITextField *testInput;
@property(nonatomic,strong)UIButton *jumpButton;
@end

@implementation TestViewController
- (void)viewDidLoad {
    self.title = @"测试demo";
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.testInput = [[UITextField alloc]init];
    self.testInput.placeholder = @"请输入URL";
//    self.testInput.text = @"https://test-open.czb365.com/redirection/todo/?platformType=92622121&platformCode=18911253707";
    self.testInput.layer.borderWidth = 1;
    self.testInput.layer.borderColor = [[UIColor grayColor] CGColor];
    self.testInput.frame = CGRectMake(10, 100, self.view.bounds.size.width - 20, 30);
    [self.view addSubview:self.testInput];
    self.jumpButton = [[UIButton alloc] initWithFrame:CGRectMake(50, self.view.bounds.size.height - 200, self.view.bounds.size.width - 100, 50)];
    self.jumpButton.backgroundColor = [UIColor redColor];
    [self.jumpButton setTintColor:[UIColor whiteColor]];
    [self.jumpButton setTitle:@"加载" forState:UIControlStateNormal];
    [self.jumpButton addTarget:self action:@selector(jumpToWeb) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.jumpButton];
    [self addTap];
}
- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
}
-(void)jumpToWeb{
    if(self.testInput.text.length == 0){
        return;
    }
    WebViewController *vc = [[WebViewController alloc] init];
    vc.url = self.testInput.text;
    
    [self.navigationController pushViewController:vc animated:YES];
}
-(void)addTap{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(registerTextInput)];
    [self.view addGestureRecognizer:tap];
}
-(void)registerTextInput{
    [self.testInput resignFirstResponder];
}
@end

